package com.spring.ioc;

public class Teacher {
  int salary;
  int teacherId;
  public Teacher(int salary,int teacherId) {
	  this.salary=salary;
	  this.teacherId=teacherId;
  }
  public String toString() {
	  return("teacher salary is"+salary+ "id of teacher"+teacherId);
  }
}
