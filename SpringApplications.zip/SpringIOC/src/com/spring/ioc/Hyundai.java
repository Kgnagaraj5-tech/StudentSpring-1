package com.spring.ioc;

public class Hyundai implements FourWheeler{

	@Override
	public String getFourWheeDet() {
		return "Iten cost 5lac";
	}

}
