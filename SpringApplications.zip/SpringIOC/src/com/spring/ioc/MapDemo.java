package com.spring.ioc;
import java.util.*;
public class MapDemo {
public static void main(String[] args) {
	Map<Integer,String> map=new HashMap<Integer,String>();
	map.put(101,"durga");
	map.put(102, "ravi");
	map.put(101,"suresh");
	System.out.println(map);
	
	
}
}
