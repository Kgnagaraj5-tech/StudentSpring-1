package com.spring.ioc;

public class CakePreparation implements ICakePreparation{

	@Override
	public String getPreparationDetails() {
		return "Cake preparation needs flour,eggs,milk,butter,venilla etc..";
	}

	
}
