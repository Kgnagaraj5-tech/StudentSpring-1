package com.spring.ioc;

public class Studying implements MadhuInterface{

	@Override
	public void madhuWorks() {
		System.out.println("Madhu Studies JAVA and Java Script");
	}
}
