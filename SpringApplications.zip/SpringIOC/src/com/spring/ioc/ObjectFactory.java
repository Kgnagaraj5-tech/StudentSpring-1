package com.spring.ioc;

public class ObjectFactory implements Automobile {

	@Override
	public TwoWheeler getInstance() {
		return twoWheelerobj;
	}
	@Override
	public FourWheeler getObject() {
		return fourWheelobj;
	}
	private TwoWheeler twoWheelerobj;
	private FourWheeler fourWheelobj;
	public ObjectFactory(TwoWheeler twoWheelerobj) {
		this.twoWheelerobj=twoWheelerobj;
	}
    public ObjectFactory(FourWheeler fourWheelobj) {
    	this.fourWheelobj=fourWheelobj;
    }
}
