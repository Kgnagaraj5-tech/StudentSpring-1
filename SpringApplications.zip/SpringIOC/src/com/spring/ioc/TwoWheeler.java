package com.spring.ioc;

public interface TwoWheeler {
   public String getDetails();
}
