package com.spring.ioc;

public class Honda implements TwoWheeler {

	@Override
	public String getDetails() {
		return "Unicorn-150 cost 80k";
	}

}
