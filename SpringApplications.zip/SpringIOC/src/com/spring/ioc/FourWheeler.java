package com.spring.ioc;

public interface FourWheeler {
 public String getFourWheeDet();
}
