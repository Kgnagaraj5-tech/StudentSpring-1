package com.spring.ioc;

public interface MadhuInterface {

	public String getMadhuWorks();
}
