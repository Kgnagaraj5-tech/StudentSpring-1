package com.spring.ioc;

public class Cooking implements MadhuInterface{

	private ICakePreparation cakePreparation;
	
	public Cooking(ICakePreparation cakePreparation) {
		this.cakePreparation = cakePreparation;
	}
	
	@Override
	public String getMadhuWorks() {
		return "Madhu prepares Cakes Well and its ingredients are "+cakePreparation.getPreparationDetails();
	}
	
	

}
