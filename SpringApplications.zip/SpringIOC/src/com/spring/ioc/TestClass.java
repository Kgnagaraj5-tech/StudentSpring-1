package com.spring.ioc;

public class TestClass {
public static void main(String[] args) {
	PhysicsTeacher ps=new PhysicsTeacher(10000,12,03);
	System.out.println(ps.toString());
}
}
