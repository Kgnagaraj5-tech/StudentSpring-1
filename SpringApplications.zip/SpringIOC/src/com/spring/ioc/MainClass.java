package com.spring.ioc;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		/*MadhuInterface madhuInterfacec = new Cooking();
		MadhuInterface madhuInterfaces = new Studying();
		
		madhuInterfacec.madhuWorks();
		madhuInterfaces.madhuWorks();*/
		/*ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("/com/spring/ioc/springBeans.xml");
		MadhuInterface madhu=context.getBean("myday",MadhuInterface.class);
		ICakePreparation cakePreparation = context.getBean("cake",ICakePreparation.class);
		System.out.println("Only Ingredient Details --> "+cakePreparation.getPreparationDetails());
		System.out.println(madhu.getMadhuWorks());
		context.close();*/
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("com/spring/ioc/springBeans.xml");
		Automobile automobile=context.getBean("objectfactoryobj",ObjectFactory.class);
		Automobile automobile1=context.getBean("objectfactoryobj1",ObjectFactory.class);
		System.out.println("Twowheeler details--"+automobile1.getInstance().getDetails());
		System.out.println("FourWheeler details--"+automobile.getObject().getFourWheeDet());
	}
}
