package com.spring.ioc;

public interface ICakePreparation {
	
	String getPreparationDetails();
}
