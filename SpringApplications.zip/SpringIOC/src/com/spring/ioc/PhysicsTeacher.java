package com.spring.ioc;

public class PhysicsTeacher extends Teacher {
  int dailyclasses;
  public PhysicsTeacher(int salary,int teacherId,int dailyclasses) {
	  super(salary,teacherId);
	  this.dailyclasses=dailyclasses;
  }
  
  public String toString() {
	  return(super.toString()+"\n dailyclasses"+dailyclasses);
  }
}
