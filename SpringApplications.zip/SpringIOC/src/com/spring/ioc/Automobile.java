package com.spring.ioc;

public interface Automobile {
  TwoWheeler getInstance();
  FourWheeler getObject();
  }
