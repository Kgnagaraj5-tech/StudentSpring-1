package it.sella.com;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;

@Component
public class MyPdfView extends AbstractPdfView{

	@Override
	protected void buildPdfDocument(Map<String, Object> map, Document doc, PdfWriter pw, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
			
		Map mapObj = (Map)map;
		ArrayList list = (ArrayList)mapObj.get("result");
		Paragraph p = new Paragraph();
		p.setAlignment("center");
		doc.add(p);
		Table table = new Table(1);
		table.addCell(list.get(0)+"  ");
		table.addCell(list.get(1)+"  ");
		table.addCell(list.get(2)+"  ");
		doc.add(table);
		
	}
}
