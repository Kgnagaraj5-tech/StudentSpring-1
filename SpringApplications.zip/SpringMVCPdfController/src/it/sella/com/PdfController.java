package it.sella.com;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;


public class PdfController extends AbstractController{

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List list=new ArrayList();
		list.add(1004);
		list.add("Sanjay");
		list.add(5000f);
		return new ModelAndView("viewbean","result",list);
	}
}
