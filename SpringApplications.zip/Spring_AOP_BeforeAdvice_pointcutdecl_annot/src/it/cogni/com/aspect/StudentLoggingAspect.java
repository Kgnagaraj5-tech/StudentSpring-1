package it.cogni.com.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class StudentLoggingAspect {

	@Pointcut("execution(* it.cogni.com.dao.*.add*(..))")
	private void onAddMethods() {}
	
	@Pointcut("execution(* it.cogni.com.dao.*.print*(..))")
	private void onPrintMethods() {}
	
	
	/*@Before("onAddMethods()")
	public void beforeAddStudentAdvice() {
		System.out.println("\n ==> Executing @Before advice on method ");
	}*/
	
	@Before("onPrintMethods()")
	public void beforeStudentAnalytics() {
		System.out.println("\n ==>  Analysis of the student details branch wise called before all business methods start with print ");
	}
	
	@Before("onPrintMethods()")
	public void beforeStudentAnalyticsAndFee() {
		System.out.println("\n ==> Calling before the print* methods ");
		System.out.println("\n ==> Fee structure should not be exceed 1Lakh deposit");
	}
	
}

