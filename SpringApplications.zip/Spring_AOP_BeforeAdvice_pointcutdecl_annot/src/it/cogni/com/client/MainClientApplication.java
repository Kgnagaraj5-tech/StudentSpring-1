package it.cogni.com.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import it.cogni.com.bean.College;
import it.cogni.com.config.StudentConfig;
import it.cogni.com.dao.CollegeDAO;
import it.cogni.com.dao.StudentDAO;

public class MainClientApplication {

	public static void main(String[] args) {
		
		//read spring config java class
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(StudentConfig.class);
		
		//get the bean from spring container
		StudentDAO studentDao = context.getBean("studentDAO",StudentDAO.class);
		
		//get the CollegeDAO bean from container
		CollegeDAO collegeDao = context.getBean("collegeDAO",CollegeDAO.class);
		
		//call the business method
		studentDao.addStudent();
		System.out.println("=========================");
		studentDao.addCollegeStudent();
		System.out.println("=========================");
		studentDao.addStudent1(); // @Before advice method should not be called on this method as return type is void
		
		System.out.println("=========================");
		System.out.println("=========================");
		
		collegeDao.addStudent();  // @Before advice method should not be called on this method as return type is void
		System.out.println("=========================");
		collegeDao.addCollegeLibrarian();
		System.out.println("=========================");
		collegeDao.addCollege(new College(1002,"Computer Science"));
		System.out.println("=========================");
		collegeDao.printCollege();
		
		//lets call the addStudent() method again to check if the aspect is called again or not
		//studentDao.addStudent();
		
		//close the context
		context.close();
		
	}
}
