package com;

public class StaticFactoryBeanTest {

	private StaticFactoryBeanTest() {
		System.out.println("Private Constructor");
	}
	
	public static StaticFactoryBeanTest getInstance() {
		return new StaticFactoryBeanTest();
	}
	
	public String display() {
		return "This is display method called from StaticFactoryBeanTest class";
	}
	
}
