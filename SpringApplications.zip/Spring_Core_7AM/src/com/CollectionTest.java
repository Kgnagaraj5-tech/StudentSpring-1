package com;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;

public class CollectionTest {

	private List carCompanies;
	private Set states;
	private Set<Integer> pincodes;
	private Map<String,String> stateCap;
	private Vector carModels;
	private Properties properties;
	
	
	
	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public Vector getCarModels() {
		return carModels;
	}

	public void setCarModels(Vector carModels) {
		this.carModels = carModels;
	}

	public Map<String, String> getStateCap() {
		return stateCap;
	}

	public void setStateCap(Map<String, String> stateCap) {
		this.stateCap = stateCap;
	}

	public Set getPincodes() {
		return pincodes;
	}

	public void setPincodes(Set pincodes) {
		this.pincodes = pincodes;
	}

	public Set getStates() {
		return states;
	}

	public void setStates(Set states) {
		this.states = states;
	}

	public List getCarCompanies() {
		return carCompanies;
	}

	public void setCarCompanies(List carCompanies) {
		this.carCompanies = carCompanies;
	}

	@Override
	public String toString() {
		return "CollectionTest [carCompanies=" + carCompanies + ", states=" + states + ", pincodes=" + pincodes
				+ ", stateCap=" + stateCap + ", carModels=" + carModels + ", properties=" + properties + "]";
	}
	
		
}
