package com;

public class SampleA {

	public SampleA(SampleB obj) {
		System.out.println("SampleA single  parameterised constructor");
		obj.display();
	}
	
	public void display() {
		System.out.println("SampleA class display() method");
	}
}
