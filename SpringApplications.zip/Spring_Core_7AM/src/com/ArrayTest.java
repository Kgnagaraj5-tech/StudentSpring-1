package com;

import java.util.Arrays;

public class ArrayTest {

	private String name[];

	public String[] getName() {
		return name;
	}

	public void setName(String[] name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "ArrayTest [name=" + Arrays.toString(name) + "]";
	}
	
}
