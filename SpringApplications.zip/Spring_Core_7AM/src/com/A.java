package com;

import java.util.Date;

public class A {

	public A() {
		System.out.println("A class user defined constructor");
	}
	
	//Non - static factory method
	public Date getDate() {
		return new Date();
	}
	
	//Factory method returnig object of B class 
	public B getB() {
		return new B();
	}
	
	//This is a normal non static method which returns an int type value
	public int sum(int a,int b) {
			 return (a + b);
		}
	
	public String display() {
		return "Simple display method of A class";
	}
	
	
}
