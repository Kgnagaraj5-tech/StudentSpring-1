package com;

public class B {

	public B() {
		System.out.println("No - Arg B class constructor");
	}
	
	public void show() {
		System.out.println("B class show() method ");
	}
	
}
