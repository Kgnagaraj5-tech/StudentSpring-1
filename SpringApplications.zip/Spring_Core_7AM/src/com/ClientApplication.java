package com;

import java.util.Enumeration;
import java.util.Properties;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class ClientApplication {

	public static void main(String[] args) {
		
		Resource r = new ClassPathResource("./spring_bean1.xml");
		BeanFactory factory = new XmlBeanFactory(r); // Here we created Spring Core Container(IOC container)
		Object obj = factory.getBean("emp_obj"); // by calling getBean("emp_obj") method the container will create object of the 
																				// specified bean and load it(make it available)
		/*Employee e = (Employee)obj;
		System.out.println(e);
		System.out.println("================");
		e.setEno(102);
		e.setEname("Dinesh");
		e.setSalary(12000);
		System.out.println(e);
		
		ArrayTest arr_test = (ArrayTest)factory.getBean("arr_Test");
		String name[] = arr_test.getName();
		System.out.println("============================"); 
		for(String name1 : name) {
			System.out.println(name1);
		}
		
		ArrayObjectTest arrObj1 = (ArrayObjectTest)factory.getBean("objArr");
		Address address[] = arrObj1.getAddress();
		for(Address addr : address) {
			System.out.println("===========================");
			System.out.println("City --> "+addr.getCity());
			System.out.println("State --> "+addr.getState());
			System.out.println("Pincode --> "+addr.getPinCode());
			System.out.println("===========================");
		}*/
		
		//Collection injection Testing
		
		CollectionTest collTest = (CollectionTest)factory.getBean("collTest");
		System.out.println(collTest.getCarCompanies());
		
		System.out.println(collTest.getStates());
		
		System.out.println(collTest.getPincodes());
		
		System.out.println(collTest.getStateCap());
		
		System.out.println(collTest.getCarModels());
		
		Properties prop = collTest.getProperties();
		Enumeration enum1 = prop.elements();
		while(enum1.hasMoreElements()) {
			System.out.println(enum1.nextElement());
		}
		
		A oa1 = (com.A)factory.getBean("aa1");
		System.out.println("Sum of two numbers --> "+oa1.sum(10, 10)); // 20
		
		B ob1 = (com.B)factory.getBean("b1");
		ob1.show();
		
		StaticFactoryBeanTest test = (StaticFactoryBeanTest)factory.getBean("staticObj");
		System.out.println(test.display());
		
		ScopeCheck sck = (ScopeCheck)factory.getBean("scopeChk");
		sck.setName("Kiran");
		System.out.println(sck.getName());
		
		ScopeCheck sck1 = (ScopeCheck)factory.getBean("scopeChk");
		System.out.println(sck1.getName());
		
		System.out.println(sck.getName());
		
		System.out.println("ScopeCheck object Address --> "+sck);
		System.out.println("ScopeCheck object Address --> "+sck1);
		
		
		/*//Constructor Arg testing 
		ConstructorTest cntTest = (ConstructorTest)factory.getBean("cntTest");
		System.out.println(cntTest);
		
		//Constructor Ambiguity test
		Student stdObj1 = (Student)factory.getBean("stdObj");
		System.out.println(stdObj1);
		
		//Non-static factory method test
		Date d = (Date)factory.getBean("dtObj");
		System.out.println("Current Date "+d);
		
		com.A aa2 = (A)factory.getBean("aa1");
		System.out.println(aa2.display());
		
		B b12 = (B)factory.getBean("b1");
		b12.show();
		
		//Static - factory test
		StaticFactoryBeanTest test = (StaticFactoryBeanTest)factory.getBean("staticObj");
		System.out.println(test.display());
		
		SampleA sampA = (SampleA)factory.getBean("sampA");
		sampA.display();
		
		ScopeCheck sck = (ScopeCheck)factory.getBean("scopeChk");
		sck.setName("Kiran");
		System.out.println(sck.getName());
		
		ScopeCheck sck1 = (ScopeCheck)factory.getBean("scopeChk");
		System.out.println(sck1.getName());
		
		System.out.println(sck.getName());
		
		System.out.println("ScopeCheck object Address --> "+sck);
		System.out.println("ScopeCheck object Address --> "+sck1);*/
		
	}
}
