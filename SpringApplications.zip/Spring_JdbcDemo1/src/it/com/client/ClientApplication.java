package it.com.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import it.com.beans.Student;
import it.com.dao.StudentDao;

public class ClientApplication {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringApplication.xml");
		StudentDao stud_dao = (StudentDao)context.getBean("sdao");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student ID :: ");
		int sid = sc.nextInt();
		System.out.println("Enter Student Name :: ");
		String sname = sc.next();
		System.out.println("Enter Student Marks ::");
		int marks = sc.nextInt();
		Student student = new Student(sid,sname,marks);
		stud_dao.persistStudent(student);
		
	}
}
