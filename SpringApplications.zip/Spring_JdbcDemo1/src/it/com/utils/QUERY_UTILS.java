package it.com.utils;

public interface QUERY_UTILS {

	public static final String INSERT_STUD_REC="insert into student(sid,sname,marks) values (?,?,?)";
	
}
