package it.com.dao;

import java.sql.Types;

import org.springframework.jdbc.core.JdbcTemplate;

import it.com.beans.Student;
import it.com.utils.QUERY_UTILS;

public class StudentDao {

	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public void persistStudent(Student student) {
		System.out.println("Inside Persist Student method");
		jdbcTemplate.update(QUERY_UTILS.INSERT_STUD_REC, 
				new Object[] {student.getSid(),student.getSname(),student.getMarks()}, 
				new int[] {Types.INTEGER,Types.VARCHAR,Types.INTEGER});
	}
}
