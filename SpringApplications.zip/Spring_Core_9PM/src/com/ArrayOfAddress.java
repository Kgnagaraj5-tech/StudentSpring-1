package com;

import java.util.Arrays;

public class ArrayOfAddress {
	
	private Address[] arrAddress;

	public Address[] getArrAddress() {
		return arrAddress;
	}

	public void setArrAddress(Address[] arrAddress) {
		this.arrAddress = arrAddress;
	}

	@Override
	public String toString() {
		return "ArrayOfAddress [arrAddress=" + Arrays.toString(arrAddress) + "]";
	}
	
	

}
