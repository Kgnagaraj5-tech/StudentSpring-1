package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class ClientApplication {

	public static void main(String[] args) {
		
		Resource resource = new ClassPathResource("./SpringConfig.xml");
		BeanFactory factory = new XmlBeanFactory(resource); // here we created a container object with no beans in it.
		
		Address address1 = (Address)factory.getBean("addr");
		Address address2 = (Address)factory.getBean("addr1");
		Address address3 = (Address)factory.getBean("addr2");
		
		
		Student stud = (Student)factory.getBean("student");
		System.out.println(stud);
		
		ArrayOfAddress arrAddr = (ArrayOfAddress)factory.getBean("arrAddr");
		System.out.println(arrAddr);
		
		ArrayOfNames arrName = (ArrayOfNames)factory.getBean("arrName");
		System.out.println(arrName);
		
		Address addr3 = (Address)factory.getBean("addr3");
		System.out.println(addr3);
		
		Student stud3 = (Student)factory.getBean("stud3");
		System.out.println(stud3);
		
	}
}
