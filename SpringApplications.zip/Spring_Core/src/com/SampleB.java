package com;

public class SampleB {

	public SampleB() {
		System.out.println("SampleB class one parameterised constructor");
	}
	
	public void display() {
		System.out.println("SampleB class display() method");
	}
}
