package com;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

public class CollectionBeanTest {

	private List carCompanies;
	private Set states;
	private Map<String,String> carModels;
	private Vector capitals;
	private TreeSet cricters;
	private Properties dbDetails;
	
	public Properties getDbDetails() {
		return dbDetails;
	}
	public void setDbDetails(Properties dbDetails) {
		this.dbDetails = dbDetails;
	}
	public TreeSet getCricters() {
		return cricters;
	}
	public void setCricters(TreeSet cricters) {
		this.cricters = cricters;
	}
	public Vector getCapitals() {
		return capitals;
	}
	public void setCapitals(Vector capitals) {
		this.capitals = capitals;
	}
	public List getCarCompanies() {
		return carCompanies;
	}
	public void setCarCompanies(List carCompanies) {
		this.carCompanies = carCompanies;
	}
	public Set getStates() {
		return states;
	}
	public void setStates(Set states) { 
		this.states = states;
	}
	public Map<String, String> getCarModels() {
		return carModels;
	}
	public void setCarModels(Map<String, String> carModels) {
		this.carModels = carModels;
	}
	
	@Override
	public String toString() {
		return "CollectionBeanTest [carCompanies=" + carCompanies + ", states=" + states + ", carModels=" + carModels
				+ ", capitals=" + capitals + ", cricters=" + cricters + ", dbDetails=" + dbDetails + "]";
	}
	
}
