package com;

import java.util.Date;

public class A {

	public A() {
		System.out.println("A class user defined constructor");
	}
	
	public Date getDate() {
		return new Date();
	}
	
}
