package com;

import java.util.Arrays;

public class ArrayOfObjects {

	private Address address[];

	public Address[] getAddress() {
		return address;
	}

	public void setAddress(Address[] address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "ArrayOfObjects [address=" + Arrays.toString(address) + "]";
	}
	
}
