package com;

public class ConstructorTest {

	private String sname;
	private int sno;
	private int marks;
	private String city;
	
	
	public ConstructorTest(String sname, int sno, int marks, String city) {
		this.sname = sname;
		this.sno = sno;
		this.marks = marks;
		this.city = city;
	}


	public ConstructorTest(int sno, int marks) {
		this.sno = sno;
		this.marks = marks;
	}


	public ConstructorTest(String sname, String city) {
		this.sname = sname;
		this.city = city;
	}


	public String getSname() {
		return sname;
	}


	public void setSname(String sname) {
		this.sname = sname;
	}


	public int getSno() {
		return sno;
	}


	public void setSno(int sno) {
		this.sno = sno;
	}


	public int getMarks() {
		return marks;
	}


	public void setMarks(int marks) {
		this.marks = marks;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	@Override
	public String toString() {
		return "ConstructorTest [sname=" + sname + ", sno=" + sno + ", marks=" + marks + ", city=" + city + "]";
	}
	
	
		
}
