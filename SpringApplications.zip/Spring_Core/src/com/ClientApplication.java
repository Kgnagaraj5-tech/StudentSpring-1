package com;

import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class ClientApplication {

	public static void main(String[] args) {
		
		Resource r = new ClassPathResource("./spring.xml");
		BeanFactory factory = new XmlBeanFactory(r);
		Object object = factory.getBean("emp_obj");
		Employee employee = (Employee)object;
		System.out.println(employee);
		
		System.out.println("==================");
		
		Object obj1 = factory.getBean("arrTest");
		ArrayTest arrTest = (ArrayTest)obj1;
		String names[] = arrTest.getName();
		for(String name : names) {
			System.out.println(name);
		}
		
		// Printing addresses
		Object obj2 = factory.getBean("obj_arr");
		ArrayOfObjects arr_obj = (ArrayOfObjects)obj2;
		Address addr[] = arr_obj.getAddress();
		for(Address address : addr) {
			System.out.println("===================");
			System.out.println("City :: "+address.getCity());
			System.out.println("State :: "+address.getState());
			System.out.println("City :: "+address.getPinCode());
			System.out.println("===================");
		}
		
		//Collection properties accessing
		CollectionBeanTest cbt = (CollectionBeanTest)factory.getBean("col_test");
		List carsCompanies = cbt.getCarCompanies();
		System.out.println("List --> "+carsCompanies);
		Set states = cbt.getStates();
		System.out.println("Set --> "+states);
		Map<String,String> carModels = cbt.getCarModels();
		System.out.println("Map --> "+carModels);
		Vector<String> capitals = cbt.getCapitals();
		System.out.println("Vector --> "+capitals);
		TreeSet tSet = cbt.getCricters();
		System.out.println(tSet);
		
		//Properties object injection
		Properties prop = cbt.getDbDetails();
		if(!prop.isEmpty()) {
			Enumeration enum1 = prop.elements();
			while(enum1.hasMoreElements()) {
				System.out.println(enum1.nextElement());
			}
		}
		
		//Constructor Arg testing 
		ConstructorTest cntTest = (ConstructorTest)factory.getBean("cntTest");
		System.out.println(cntTest);
		
		SampleA sampA = (SampleA)factory.getBean("sampA");
		sampA.display();
		
		//Constructor Ambiguity test
		Student stdObj1 = (Student)factory.getBean("stdObj");
		System.out.println(stdObj1);
		
		Date d = (Date)factory.getBean("dtObj");
		System.out.println("Current Date is --> "+d);
		
		Date d1 = (Date)factory.getBean("dtObj1");
		System.out.println("Current Date -->"+d1);
   }
}
