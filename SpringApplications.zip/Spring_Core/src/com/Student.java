package com;

public class Student {

	private int sid;
	private String sname;
	private long clspin;
	private String section;
	
	
	public Student(int sid, String sname) {
		this.sid = sid;
		this.sname = sname;
	}
	
	
	public Student(long clspin, String section) {
		this.clspin = clspin;
		this.section = section;
	}


	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public long getClspin() {
		return clspin;
	}
	public void setClspin(long clspin) {
		this.clspin = clspin;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}


	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", clspin=" + clspin + ", section=" + section + "]";
	}
	
	
	
}
