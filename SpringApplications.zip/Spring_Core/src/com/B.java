package com;

import java.util.Date;

public class B {

	public B() {
		System.out.println("B class constructor");
	}
	
	public Date getCurrDate() {
		return new A().getDate();
	}
}
