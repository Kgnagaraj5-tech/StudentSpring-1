package it.com.dao;

import java.util.HashMap;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import it.com.beans.Student;
import it.com.utils.QUERY_UTILS;

public class StudentDao {

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
		return namedParameterJdbcTemplate;
	}

	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}
	
	public int persistStudent(Student student) {
		Map<String,Object> namedParams = new HashMap<String,Object>();
		namedParams.put("sid", student.getSid());
		namedParams.put("sname", student.getSname());
		namedParams.put("marks", student.getMarks());
		return namedParameterJdbcTemplate.update(QUERY_UTILS.INSERT_STUD_REC, namedParams);		
	}
}
