package it.sella.com;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MvcController {

	@RequestMapping("/")
	public String showHomePage() {
		return "Home-Page";
	}
	
	@RequestMapping("/processForm")
	public String processForm(HttpServletRequest request,Model model) {
		String name = request.getParameter("name");
		System.out.println("Name from request Object "+name);
		String inUpper = name.toUpperCase();
		String message = "Hey! "+inUpper;
		model.addAttribute("message", message);
		return "ProcessForm"; 
	}
	
}
