package it.cogni.com.client;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import it.cogni.com.bean.Student;
import it.cogni.com.config.StudentConfig;
import it.cogni.com.dao.StudentDAO;

public class MainClientApplication {

	public static void main(String[] args) {
		
		//read spring config java class
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(StudentConfig.class);
		
		//get the bean from spring container
		StudentDAO studentDao = context.getBean("studentDAO",StudentDAO.class);
		
		List<Student> studentList = studentDao.findStudents();
		
		//displaying Student details
		System.out.println("\n\n ==================");
		System.out.println(studentList);
			
		//close the context
		context.close();
		
	}
}
