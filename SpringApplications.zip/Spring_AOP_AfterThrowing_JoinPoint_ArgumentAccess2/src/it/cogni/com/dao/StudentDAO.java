package it.cogni.com.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import it.cogni.com.bean.Student;

@Component
public class StudentDAO {
	
	private Student student;

	public List<Student> findStudents(){
		Map<Integer,Student> studentMap = new HashMap<Integer,Student>();
		List<Student> studentsList = new ArrayList<Student>();
		Student student1 = new Student(100,"Kiran");
		Student student2 = new Student(101,"Rajesh");
		Student student3 = new Student(102,"Praveen");
		Student student4 = new Student(103,"Pravallika");
		studentsList.add(student1);
		studentsList.add(student2);
		studentsList.add(student3);
		studentsList.add(student4);
		if(studentsList.size() <= 3) {
			throw new RuntimeException("Student List size should be greater than 3 ");
		}
		return studentsList;
	}
	
	public void printInfo() {
		System.out.println("This is a printInfo() method of StudentDAO class ");
	}
	
}
