package it.com;

public interface Department {

	public String getDeptName();
	
	public String getEmpName();
}
