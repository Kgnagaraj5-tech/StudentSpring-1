package it.com;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class EmployeeDetails implements Department{

	@Autowired
	@Qualifier(value="randomEmpName")
	private Employee employee;
	
	private String[] departmentNames = {
			"Sales","Marketing","Hr","IncomeTax"
	};
	
	private Random random = new Random();
	
	@Value("${email}")
	private String cmpnyEmail;
	
	@Value("${cmpnyTag}")
	private String cmpnyTag;
	
	
	@Override
	public String getDeptName() {
		int index = random.nextInt(departmentNames.length);
		return departmentNames[index];
	}

	@Override
	public String getEmpName() {
		return employee.getEmpName();
	}

	public String getCmpnyEmail() {
		return cmpnyEmail;
	}

	public String getCmpnyTag() {
		return cmpnyTag;
	}

	

}
