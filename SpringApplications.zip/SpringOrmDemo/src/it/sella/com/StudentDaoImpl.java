package it.sella.com;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("studentDao")
public class StudentDaoImpl extends CustomHibernateDaoSupport implements IStudentDao{

	@Override
	public void saveStudent(Student student) {
		getHibernateTemplate().saveOrUpdate(student);
	}

	@Override
	public List<Student> getStudents() {
		return getHibernateTemplate().loadAll(Student.class);
	}

}
