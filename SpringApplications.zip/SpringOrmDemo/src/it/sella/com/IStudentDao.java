package it.sella.com;

import java.util.List;

public interface IStudentDao {

	public void saveStudent(Student student);
	public List<Student> getStudents();
	
}
