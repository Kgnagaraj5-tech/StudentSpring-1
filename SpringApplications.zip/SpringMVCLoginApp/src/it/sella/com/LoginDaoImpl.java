package it.sella.com;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class LoginDaoImpl implements ILoginDao {

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public String getName(Login login) {
		Login login1 = new Login();
		String name = "";
		try {
			login1 = jdbcTemplate.queryForObject("select fnm,lnm,usn,pass from login where usn = ? and pass = ?",
					new Object[] {login.getUserName(),login.getPassword()},
					new RowMapper<Login>() {
						@Override
						public Login mapRow(ResultSet rs, int arg1) throws SQLException {
							Login login2 = new Login();
							login2.setFirstName(rs.getString("fnm"));
							login2.setLastName(rs.getString("lnm"));
							login2.setUserName(rs.getString("usn"));
							login2.setPassword(rs.getString("pass"));
							return login2;
						}});
		} catch (DataAccessException e) {
			System.out.println(e.getLocalizedMessage());
			return "NoResult";
		}
		System.out.println(login1.getFirstName() + "  " + login1.getLastName());
		name = login1.getFirstName() + "  " + login1.getLastName();
		return name;
	}

}
/*
 * jdbcTemplate.
 * queryForObject("select lnm from login where usn = ? and pass = ?", new
 * Object[] {login.getUserName(),login.getPassword()}, new int[]
 * {Types.VARCHAR,Types.VARCHAR} );
 * 
 */