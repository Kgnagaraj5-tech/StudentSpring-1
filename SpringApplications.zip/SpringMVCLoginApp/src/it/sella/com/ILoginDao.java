package it.sella.com;

public interface ILoginDao {

	public String getName(Login login);
	
}
