package it.sella.com;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {

	@Autowired
	LoginDaoImpl loginDao;
	
	@RequestMapping("/")
	public String getLoginPage() {
		return "Login";
	}
	
	@RequestMapping("/login")
	public String processForm(HttpServletRequest request,Model model) {
		String page = null;
		String userName = request.getParameter("user");
		String password = request.getParameter("password");
		Login login = new Login(userName,password);
		String name = loginDao.getName(login);
		System.out.println("Name is --> "+name);
		model.addAttribute("name",name);
		if(!name.equals("NoResult") && !name.equals("") && name != null) {
			return "Success";
		}else {
			return "Failure";
		}
	}
}
