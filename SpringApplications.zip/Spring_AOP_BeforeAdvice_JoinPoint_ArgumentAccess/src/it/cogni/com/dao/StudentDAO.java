package it.cogni.com.dao;

import org.springframework.stereotype.Component;

import it.cogni.com.bean.Student;

@Component
public class StudentDAO {
	
	private Student student;

	public void addStudent1() {
		System.out.println(getClass() + " ::  Add DB Code for addStudent1()");
	}
	
	public String addStudent() {
		System.out.println(getClass() + " :: This method addStudent() is with return type as String Object ");
		return "StringType";
	}
	
	public void addStudent(Student student,boolean flag) {
		this.student = student; 
		System.out.println(getClass() +" ::   Method for adding a new student with void return type");
	}
	
	public String addCollegeStudent() {
		System.out.println(getClass() + " :: This method addCollegeStudent() is with return type as String Object ");
		return "CollegeStudent";
	}
	
	public void printStudent() {
		System.out.println("Student ID :: "+student.getSid());
		System.out.println("Student Name :: "+student.getSname() != null ? student.getSname() : "No Name");
	}
	
	public void printInfo() {
		System.out.println("This is a printInfo() method of StudentDAO class ");
	}
	
}
