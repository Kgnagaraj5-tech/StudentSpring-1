package it.cogni.com.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Order(1)
public class StudentLoggingAspect {

	@Pointcut("execution(* it.cogni.com.dao.*.printStudent*())")
	private void onPrintStudent() {}
	
	@Pointcut("execution(* it.cogni.com.dao.*.printCollege*())")
	private void onCollege() {}

	
	@Before("onPrintStudent()")
	public void beforeStudentAnalytics() {
		System.out.println("\n ==>  This is executed atlast as part of Aspect ordering on the printStudent methods ############");
	}
	
	@Before("onCollege()")
	public void collegeAnalytics() {
		System.out.println("\n ==> This is executed atlast as part of Aspect ordering on the printCollege methods @@@@@@@@@@");
	}
	
}

