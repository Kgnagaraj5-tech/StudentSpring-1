package it.com;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientApplication {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("Spring_ApplicationContext.xml");
		
		Department department = context.getBean("departmentImpl",DepartmentImpl.class);
		System.out.println(department.getDeptName());
		System.out.println(department.getEmpName());
		
	}
}
