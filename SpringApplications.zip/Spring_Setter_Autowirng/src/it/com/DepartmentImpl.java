package it.com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DepartmentImpl implements Department{

	private Employee employee;
	
	public DepartmentImpl() {
		System.out.println("No - Arg constructor of DepartmentImpl class");
	}

	@Autowired
	public void setEmployee(Employee employee) {
		System.out.println("DepartmentImpl :: Inside this setEmployee() method");
		this.employee = employee;
	}
	
	/*@Autowired
	public void retrieveEmployee(Employee employee) {
		System.out.println("DepartmentImpl :: Inside this setEmployee() method");
		this.employee = employee;
	}*/
	
	@Override
	public String getDeptName() {
		return "Sales";
	}

	@Override
	public String getEmpName() {
		return employee.getEmpName();
	}

	
}
