package it.com;

import org.springframework.stereotype.Component;

@Component
public class EmployeeImpl implements Employee{
	
	
	public EmployeeImpl() {
		System.out.println("No - arg Constructor of EmployeeImpl class");
	}

	@Override
	public String getEmpName() {
		return "Nagaraj";
	}
	
}
