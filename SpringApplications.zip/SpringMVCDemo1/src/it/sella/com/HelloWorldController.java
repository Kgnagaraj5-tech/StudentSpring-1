package it.sella.com;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloWorldController {

	@RequestMapping("/showForm")
	public String showForm() {
		return "hello-form";
	}
	
	@RequestMapping("/processForm")
	public String processForm(HttpServletRequest request,Model model) {
		String studentName = (String)request.getParameter("name1");
		model.addAttribute("sname",studentName.toUpperCase().concat("ARAJ"));
		studentName = String.valueOf(studentName.hashCode());
		model.addAttribute("hashCode",studentName);
		return "displayForm";
	}
	
}
