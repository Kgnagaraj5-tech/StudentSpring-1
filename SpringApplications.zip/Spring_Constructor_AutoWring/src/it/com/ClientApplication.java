package it.com;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientApplication {

	public static void main(String[] args) {
		
		// read spring config file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("Spring_ApplicationContext.xml");
		
		// get the bean from spring container
		//Employee employee = context.getBean("employeeImpl",EmployeeImpl.class);
		
		//call a method on the bean
		//System.out.println(employee.getEmpName());
		
		// get the bean from the container 
		Department department = context.getBean("departmentImpl",DepartmentImpl.class);
		System.out.println(department.getDeptName());
		System.out.println(department.getEmpName());
		
		context.close();
	}
}
