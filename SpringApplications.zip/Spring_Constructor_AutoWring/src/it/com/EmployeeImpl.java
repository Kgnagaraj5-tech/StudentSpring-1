package it.com;

import org.springframework.stereotype.Component;

@Component
public class EmployeeImpl implements Employee{

	@Override
	public String getEmpName() {
		return "Nagaraj";
	}

}
