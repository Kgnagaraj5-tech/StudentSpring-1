package it.com;

public interface Employee {

	public String getEmpName();
	
}
