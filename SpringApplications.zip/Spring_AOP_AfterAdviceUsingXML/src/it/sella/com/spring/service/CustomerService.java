package it.sella.com.spring.service;

public interface CustomerService {

	String printName();
	String printUrl();
	void printException();
	
}
