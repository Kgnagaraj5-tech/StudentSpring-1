package it.cogni.com.aspect;

import java.util.Iterator;
import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import it.cogni.com.bean.Student;

@Aspect
@Component
@Order(1)
public class StudentLoggingAspect {
	
	@AfterReturning(pointcut="execution(* it.cogni.com.dao.StudentDAO.findStudents(..))",returning="studentsList")
	public void afterReturningFindStudents(JoinPoint joinPoint,List<Student> studentsList) {
		System.out.println("##########INSIDE AFTERRETURNING ADVICE###########");
		String methodName = joinPoint.getSignature().toShortString();
		System.out.println("\n Executing Advice after executing the business method :: "+methodName);
		System.out.println("Student Details Display inside AfterReturning Advice :: ");
		System.out.println(studentsList);
		System.out.println("Display of Student List is done inside AfterReturning Advice");
		Iterator<Student> stIterator = studentsList.iterator();
		while(stIterator.hasNext()) {
			Student stud  = stIterator.next();
			if(stud.getSid() == 101) {
				stIterator.remove();
			}
		}
	}

	@Pointcut("execution(* it.cogni.com.dao.*.printStudent*())")
	private void onPrintStudent() {}
	
	@Pointcut("execution(* it.cogni.com.dao.*.printCollege*())")
	private void onCollege() {}

	
	@Before("onPrintStudent()")
	public void beforeStudentAnalytics() {
		System.out.println("\n ==>  This is executed atlast as part of Aspect ordering on the printStudent methods");
	}
	
	@Before("onCollege()")
	public void collegeAnalytics() {
		System.out.println("\n ==> This is executed atlast as part of Aspect ordering on the printCollege methods");
	}
	
}

