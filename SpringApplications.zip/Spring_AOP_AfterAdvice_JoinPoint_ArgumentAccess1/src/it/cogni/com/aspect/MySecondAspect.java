package it.cogni.com.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Order(2)
public class MySecondAspect {

	@Pointcut("execution(* it.cogni.com.dao.*.*Info())")
	private void onInfoMethods() {}
	
	@Before("onInfoMethods()")
	public void beforeStudentAnalytics() {
		System.out.println("\n ==>  This Advice is called as second order and will be applicable on Info methods");
	}
	
	
}
