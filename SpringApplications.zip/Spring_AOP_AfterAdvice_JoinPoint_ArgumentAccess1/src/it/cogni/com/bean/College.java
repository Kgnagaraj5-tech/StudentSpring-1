package it.cogni.com.bean;

public class College {
	
	private int colgeId;
	private String branchName;
	
	
	public College(int colgeId, String branchName) {
		this.colgeId = colgeId;
		this.branchName = branchName;
	}
	
	public int getColgeId() {
		return colgeId;
	}
	public void setColgeId(int colgeId) {
		this.colgeId = colgeId;
	}
	
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	
	
	
}
