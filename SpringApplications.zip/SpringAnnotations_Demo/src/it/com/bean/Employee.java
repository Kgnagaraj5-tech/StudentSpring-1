package it.com.bean;

public interface Employee {

	public String getEmplName();
	
}
