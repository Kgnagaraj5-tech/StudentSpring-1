package it.com.bean;

import org.springframework.stereotype.Component;

@Component(value="emp_obj")
public class Employee_Impl implements Employee{

	@Override
	public String getEmplName() {
		return "Nagaraj";
	}

}
