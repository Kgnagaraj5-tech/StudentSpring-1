package it.com.bean;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientApplication {

	public static void main(String[] args) {
		
		//read spring config file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("Spring_ApplicationContext.xml");
		
		//get the bean from spring container
		Employee employee = context.getBean("emp_obj",Employee_Impl.class);
		
		System.out.println(employee.getEmplName());
		
		context.close();
	}
}
