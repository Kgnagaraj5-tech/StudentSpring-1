package it.sella.com;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CourseCodeConstraintValidator implements ConstraintValidator<CourseCode,String>{

	private String value;
	
	@Override
	public void initialize(CourseCode theCode) {
		value = theCode.value();
	}

	@Override
	public boolean isValid(String sourceCode, ConstraintValidatorContext constraintValidatorContext) {
			boolean result;
			if(sourceCode != null) {
				result = sourceCode.startsWith(value);
			}else {
				result = true;
			}
			
		return result;
	}

	
}
