package it.sella.com;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Custumer {

	//value = "KNR",message="Should Start with KNR"
	@CourseCode(value = "RAMESH",message="Not starting with name RAMESH")
	@NotNull(message = "is Required")
	@Size(min=1,message = "Size should be greater")
	private String courseCode;

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	@Override
	public String toString() {
		return "Custumer [courseCode=" + courseCode + "]";
	}
	
	
}
