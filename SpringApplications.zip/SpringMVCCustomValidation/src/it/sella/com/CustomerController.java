package it.sella.com;

import javax.validation.Valid;

import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/customer")
public class CustomerController {

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {

		StringTrimmerEditor stringTrimmerEditor = new StringTrimmerEditor(true);

		dataBinder.registerCustomEditor(String.class, stringTrimmerEditor);
		
	}

	@RequestMapping("/showForm")
	public String showForm(Model model) {

		// Creating Customer class object
		Custumer customer = new Custumer();

		model.addAttribute("customer", customer);

		return "ShowForm";
	}

	@RequestMapping("/processForm")
	public String processForm(@Valid @ModelAttribute("customer") Custumer theCustomer, BindingResult theBindingResult) {

		System.out.println("Last name: |" + theCustomer.getCourseCode() + "|");

		if (theBindingResult.hasErrors()) {
			return "ShowForm";
		} else {
			return "ConfirmationPage";
		}
	}
}

/*
 * Initbinder comes into picture if you want to customize the request being sent
 * to the controller.It is defined in the controller, helps in controlling and
 * formatting each and every request that comes to it. This annotation is used
 * with the methods which initializes WebDataBinder and works as a preprocessor
 * for each request coming to the controller.
 */
