package it.cogni.com.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class StudentLoggingAspect {

	//Here we add the related advice for logging
	
	//start with @Before advice [point cut matching method names]
	@Before("execution(public * print*(..))")
	public void beforeAddStudentAdvice() {
		System.out.println("****************************************************");
		System.out.println("\n ==> Executing @Before advice on business methods ");
		System.out.println("****************************************************");
	}
}

// point cuts are XML or Annotation configurations that are used to link advices with join points.
// Spring AOP uses AspectJ's pointcut experssion language
// 1) Execution pointcut is one of the method of using pointcut
// Example of Execution point cut
// execution(modifiers-pattern(optional) 
// return-type-pattern 
// declaring-type-pattern(optional)
// method-name-pattern(param-pattern) 
// throws-pattern(optional)

// If we want to match with any method of any class which starts with a substring starting
// Example ::  execution(public add*())

//Match any method with given return type
//Example :: execution(void add*()) --> match on specific return type "void" and should start with "add" as starting name of the method
//Example :: execution(* add*()) --> match on any return type but should start with the "add" as starting name of the method

//Match on parameters or on patterns
//For param-pattern matching the below given are some wildcards
// () --> matches a method with no arguments
// (*) --> matches a method with one argument of any type
// (..) --> mathches a method with 0 or more arguements of any type
//Example :: execution(* fullyqualified_package.classname.methodname(..))
//## -->  @Before("execution(* it.cogni.com.dao.*.*(..))") --> this wild card is used for accessing any class and any method with any parameters available in the 
//package it.cogni.com.dao





